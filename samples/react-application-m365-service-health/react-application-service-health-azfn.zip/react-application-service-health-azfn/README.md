# 📘 M365 Service Health Azure Functions

This project contains an Azure Function App designed to allow **all users in a Microsoft 365 tenant** to access **M365 Service Health data** via Microsoft Graph. It supports secure deployment and can be integrated with SPFx Extension react-application-service-health.

## Goals

- Provide Microsoft 365 service health data to all authenticated users.
- Use Microsoft Graph securely within Azure Functions.
- Easy deployment with zip deploy or script-based automation.

## Prerequisites

- Node.js 18+
- Azure CLI (`az`)
- Azure Functions Core Tools (`func`)
- Microsoft 365 tenant
- Microsoft Graph API permissions

## Setup Instructions

### 1. Clone the Repo

```bash
git clone <your-repo-url>
cd your-repo
```

### 2. Install Dependencies

```bash
npm install
```

### 3. Configure `local.settings.json`

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "node",
    "TENANT_ID": "<your-tenant-id>",
    "CLIENT_ID": "<your-client-id>",
    "CLIENT_SECRET": "<your-client-secret>",
  }
}
```

### 4. Develop Locally

```bash
func start
```

## Deploy to Azure

### Option 1: Manual Zip Deploy

```bash
func azure functionapp publish M365-Service-Health --publish-local-setting
```

### Option 2: Scripted Deploy

```bash
zx deployment/zx-azure-function-full-deploy/zx-deploy-function-app.mjs
```

## Azure App Registration

You can automate Azure AD app registration using the provided script.

### Option 1: Automated Registration

Run the following script to create and configure the Azure AD app:

```bash
zx deployment/zx-app-registration/zx-create-app-registration.mjs
```

This script will:

- Register an app in Azure AD.
- Grant **Application permissions**:  
  - `ServiceHealth.Read.All`
- Generate a client secret.
- Output the required values for your `local.settings.json`.

### Option 2: Manual Registration

1. Register an app in Azure AD via the Azure Portal.
2. Grant **Application permissions**:  
   - `ServiceHealth.Read.All`
3. Generate a client secret.
4. Use **client credentials flow** inside the Azure Function.

## 📡 API Endpoint

```
https://M365-Service-Health.azurewebsites.net/api/M365ServiceHealthOverviews
```

## 📄 License

MIT or your preferred license.
