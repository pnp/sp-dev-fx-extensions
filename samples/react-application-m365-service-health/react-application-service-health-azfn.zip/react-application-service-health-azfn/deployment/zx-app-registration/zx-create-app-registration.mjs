#!/usr/bin/env zx

import { $ } from "zx";

console.log(
  "Create an Azure AD app registration to use on M365 Service Health..."
);

console.log("login...");
await $`m365 login `;

console.log("Creating new app registration from manifest…");
const creation =
  await $`m365 entra app add --manifest @manifest.json   --grantAdminConsent --output json`.quiet();
const newApp = JSON.parse(creation.stdout);

const NEW_APP_ID = newApp.appId;

console.log("App registration created successfully.");
console.log("App ID:", NEW_APP_ID);

