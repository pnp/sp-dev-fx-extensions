#!/usr/bin/env zx

import { $ } from 'zx';

const appName = 'M365-Service-Health';
const resourceGroup = 'M365-Service-Health-rg';
const storageAccount = 'm365servicehealthsa';
const region = 'westeurope';
const runtime = 'node';
const projectPath = "../../";

// ---- LOGIN ----
 await $`az login  `;
console.log("Logged in to Azure successfully.");

// ---- RESOURCE GROUP ----
const rgExists = await $`az group exists --name ${resourceGroup}`;
if (rgExists.stdout.trim() !== "true") {
  console.log(`Creating resource group: ${resourceGroup}`);
  await $`az group create --name ${resourceGroup} --location ${region}`;
}
// ---- STORAGE ACCOUNT ----
const saExists =
  await $`az storage account check-name --name ${storageAccount}`;
if (JSON.parse(saExists.stdout).nameAvailable) {
  console.log(`Creating storage account: ${storageAccount}`);
  await $`az storage account create --name ${storageAccount} --location ${region} --resource-group ${resourceGroup} --sku Standard_LRS`;
} else {
  console.log(
    `Storage account "${storageAccount}" already exists or is in use.`
  );
}
// ---- FUNCTION APP ----
const appExists =
  await $`az functionapp show --name ${appName} --resource-group ${resourceGroup}`.nothrow();
if (appExists.exitCode !== 0) {
  console.log(`Creating Function App: ${appName}`);
  await $`az functionapp create --resource-group ${resourceGroup} --consumption-plan-location ${region} --runtime ${runtime} --functions-version 4 --name ${appName} --storage-account ${storageAccount}`;
} else {
  console.log(`Function App "${appName}" already exists.`);
}
// ---- DEPLOY ----
console.log("Deploying Function App...");
console.log("Building the project...");
const buildtatus = await $({
  cwd: projectPath,
})`npm run build `;
if (buildtatus.exitCode !== 0) {
  console.error("Build failed.");
  console.error(buildtatus.stderr);
  process.exit(1);
}
console.log("Build completed successfully.");
console.log("Publishing Function App...");
const publishStatus = await $({
  cwd: projectPath,
})`func azure functionapp publish M365-Service-Health --node --typescript --force --publish-local-settings `;
if (publishStatus.exitCode !== 0) {
  console.error("Publish failed.");
  console.error(publishStatus.stderr);
  process.exit(1);
}
console.log("Build and publish completed.");

console.log(publishStatus.stdout);
console.log("Function App deployed successfully.");
console.log("Function App URL: https://" + appName + ".azurewebsites.net");

